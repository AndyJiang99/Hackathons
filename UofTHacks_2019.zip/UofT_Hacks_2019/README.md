# UofT_Hacks_2019 Android Application
# Garb-Sort

In recent history, waste misplacement and ignorance has harmed countless animal, degraded our environment and health, and has costed us millions of dollars each year. Even with our current progressive education system, Canadians are still often unsure as to what their waste is categorized by. For this reason, we believe that we have a duty to show them where their waste should go, in a simple, and innovative way.